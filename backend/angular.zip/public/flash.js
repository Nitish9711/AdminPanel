const closeBtns = document.querySelectorAll('.close');
for(const btn of closeBtns) setTimeout(() => btn.click(), 2000);